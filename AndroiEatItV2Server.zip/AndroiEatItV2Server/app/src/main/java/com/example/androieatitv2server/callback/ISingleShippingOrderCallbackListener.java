package com.example.androieatitv2server.callback;

import com.example.androieatitv2server.Model.ShippingOrderModel;

public interface ISingleShippingOrderCallbackListener {
     void onSingleShippingOrderLoadSuccess(ShippingOrderModel shippingOrderModel);
}
