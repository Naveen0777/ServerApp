package com.example.androieatitv2server.callback;

public interface MyButtonClickListener {
    void onClick(int pos);
}
