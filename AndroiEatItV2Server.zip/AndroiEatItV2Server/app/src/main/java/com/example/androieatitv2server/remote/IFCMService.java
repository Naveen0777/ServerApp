package com.example.androieatitv2server.remote;

import io.reactivex.Observable;
import com.example.androieatitv2server.Model.FCMResponse;
import com.example.androieatitv2server.Model.FCMSendData;

import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface IFCMService {

    @Headers({
            "Content-Type:application/json",
            "Authorization:key=AAAAvmsLGc4:APA91bHIkyq2ik12hiLHd3a4Oucnk1ipoPVM78Y2gBKUGJQk5aFRA6SF1qkvFuG62NCEW5aFnFPkJYyc10CbanaSsUEdJq0gD56HEYtYTh2A4oSrgc6gCix6TvUWyuYZiYiUvk8-LttA"
    })
    @POST("fcm/send")
    Observable<FCMResponse> sendNotification(@Body FCMSendData body);
}
