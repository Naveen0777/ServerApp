package com.example.androieatitv2server.ui.order;

import android.app.DownloadManager;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.androieatitv2server.Model.OrderModel;
import com.example.androieatitv2server.callback.IOrderCallbackListener;
import com.example.androieatitv2server.common.Common;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class OrderViewModel extends ViewModel implements IOrderCallbackListener {

    private MutableLiveData<List<OrderModel>> orderModelMutableLiveData;
    private MutableLiveData<String> messageError;

    private IOrderCallbackListener listener;

    public OrderViewModel() {
       orderModelMutableLiveData=new MutableLiveData<>();
       messageError=new MutableLiveData<>();
       listener=this;
    }

    public MutableLiveData<List<OrderModel>> getOrderModelMutableLiveData() {
        loadOrderByStatus(0);
        return orderModelMutableLiveData;
    }

    public void loadOrderByStatus(int status) {

        List<OrderModel> tempList = new ArrayList<>();

        Query orderRef = FirebaseDatabase.getInstance().getReference(Common.RESTAURANT_REF)
                .child(Common.CurrentServerUser.getRestaurant())
                .child(Common.ORDER_REF)
                .orderByChild("orderStatus")
                .equalTo(status);

        orderRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot itemSnapShot : dataSnapshot.getChildren())
                {
                    OrderModel orderModel = itemSnapShot.getValue(OrderModel.class);
                    orderModel.setKey(itemSnapShot.getKey());           // don't forget.....imp
                    orderModel.setOrderNumber(itemSnapShot.getKey());

                    tempList.add(orderModel);
                }
                listener.onOrderLoadSuccess(tempList);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                listener.onOrderLoadFailed(databaseError.getMessage());

            }
        });
    }

    public MutableLiveData<String> getMessageError() {
        return messageError;
    }

    @Override
    public void onOrderLoadSuccess(List<OrderModel> orderModelList) {
        if (orderModelList.size() > 0){

            Collections.sort(orderModelList,(orderModel,t1)->{
                if (orderModel.getCreateData() < t1.getCreateData())
                    return  -1;
                return orderModel.getCreateData() == t1.getCreateData() ? 0: 1;
            });
        }

        orderModelMutableLiveData.setValue(orderModelList);

    }

    @Override
    public void onOrderLoadFailed(String message) {
        messageError.setValue(message);

    }
}