package com.example.androieatitv2server.callback;

import com.example.androieatitv2server.Model.CategoryModel;

import java.util.List;

public interface ICategoryCallbackListner {
    void onCategoryLoadSuccess(List<CategoryModel> categoryModelList);
    void onCategoryLoadFailed(String message);
}
