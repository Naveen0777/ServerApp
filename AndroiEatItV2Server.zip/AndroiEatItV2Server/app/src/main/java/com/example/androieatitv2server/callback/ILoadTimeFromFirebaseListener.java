package com.example.androieatitv2server.callback;

import com.example.androieatitv2server.Model.OrderModel;

public interface ILoadTimeFromFirebaseListener {
    void onLoadOnlyTimeSuccess(long estimateTimeInMs);
    void onLoadTimeFailed(String message);
}
