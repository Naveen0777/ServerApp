package com.example.androieatitv2server.Model.EventBus;

import com.example.androieatitv2server.Model.SizeModel;

import java.util.List;

public class UpdateSizeModel {
    private List<SizeModel> sizeModelList;


    public UpdateSizeModel(){

    }

    public List<SizeModel> getSizeModelList() {
        return sizeModelList;
    }

    public void setSizeModelList(List<SizeModel> sizeModelList) {
        this.sizeModelList = sizeModelList;
    }
}
