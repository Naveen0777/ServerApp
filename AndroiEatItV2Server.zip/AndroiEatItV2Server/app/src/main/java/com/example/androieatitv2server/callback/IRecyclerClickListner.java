package com.example.androieatitv2server.callback;

import android.view.View;

public interface IRecyclerClickListner {
    void onItemClickListener(View view, int pos);
}
