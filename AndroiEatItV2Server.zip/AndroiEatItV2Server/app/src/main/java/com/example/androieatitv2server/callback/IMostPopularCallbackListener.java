package com.example.androieatitv2server.callback;

import com.example.androieatitv2server.Model.BestDealsModel;
import com.example.androieatitv2server.Model.MostPopularModel;

import java.util.List;

public interface IMostPopularCallbackListener {
    void onListMostPopularLoadSuccess(List<MostPopularModel> mostPopularModels);
    void onListMostPopularLoadFailed(String message);
}
