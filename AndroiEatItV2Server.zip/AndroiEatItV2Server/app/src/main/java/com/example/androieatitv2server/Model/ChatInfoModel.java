package com.example.androieatitv2server.Model;

public class ChatInfoModel {
    private String createName, lastMessage;
    private long lastUpdate, createDate;

    public String getCreateName() {
        return createName;
    }

    public ChatInfoModel() {
    }

    public void setCreateName(String createName) {
        this.createName = createName;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }

    public long getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(long lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public long getCreateDate() {
        return createDate;
    }

    public void setCreateDate(long createDate) {
        this.createDate = createDate;
    }
}
