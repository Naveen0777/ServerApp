package com.example.androieatitv2server.view_holer;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.androieatitv2server.R;
import com.example.androieatitv2server.callback.IRecyclerClickListner;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class ChatListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    private Unbinder unbinder;
    @BindView(R.id.txt_email)
    public TextView txt_emil;
    @BindView(R.id.chat_message)
    public TextView txt_chat_message;

    IRecyclerClickListner listner;


    public void setListner(IRecyclerClickListner listner) {
        this.listner = listner;
    }

    public ChatListViewHolder(@NonNull View itemView) {
        super(itemView);
        unbinder= ButterKnife.bind(itemView);

        itemView.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        listner.onItemClickListener(view,getAdapterPosition());

    }
}
